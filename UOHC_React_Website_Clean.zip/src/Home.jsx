import React from "react";

export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>United Oromo Hararge Community (UOHC)</h1>
      <p>Empowering the Oromo Hararge community through unity, education, and cultural pride.</p>
    </div>
  );
}
